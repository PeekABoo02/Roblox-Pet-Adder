It's a simple browser extension, you can choose which pet to add to your Pet Simulator 99, (now are just titanics, but in the future it will be more pets), the code will change the pets code's in the game, so you will receive the pet you chose. It's a Pet Adder, Pet hacker, or Duplicator "glitch" for Roblox, Pet simulator.

You need  to enable extension developer mode.

First step 1. Go into chrome, edge, firefox etc. 
Go to the extensions page, 
turn on Developer Mode using the switch on the extensions page.

Drag the PetAdder.crx from the zip you downloaded and drag it to the extensions page.

You can turn off the developer mode after this if you want.